package com.example.carlocator;

public class GlobalVar
{
    public static boolean startSig;
}
